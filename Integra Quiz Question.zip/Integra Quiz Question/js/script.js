var quiz = {
	'question_1':[
		{'question':'What is the one thing you dont want to do during the first interview?'},
		{'option':'A. Negotiate pay'},
		{'option':'B. Connect with the interviewer'},
		{'option':'C. Communicate why you are a good fit'},
		{'option':'D. Close by arranging the next interview'},
		{'answer':[2,4]}
	]
}


var container = '';
var idcount = 0;
var answer_array = [];
for(var quiz_first in quiz){
	for(var quiz_second in quiz[quiz_first]){
		for(var quiz_third in quiz[quiz_first][quiz_second]){
			if(quiz_third == 'question'){
				container += '<div class="question">'+quiz[quiz_first][quiz_second][quiz_third]+'</div>';
			}else if(quiz_third == 'option'){
				container += '<div class="question"><label><input class="check-input" id="input-id-'+idcount+'" type="checkbox" data-type='+idcount+' /> '+quiz[quiz_first][quiz_second][quiz_third]+'</lable><div class="cor-ans-main" id="correct_div_'+idcount+'"><span class="correct_img"></span><span class="correct_div">CORRECT</span></div><div class="wrong-ans-main" id="wrong_div_'+idcount+'"><span class="wrong_img"></span><span class="wrong_div">WRONG</span></div></div>';
			}else if(quiz_third == 'answer'){
				answer_array.push(quiz.question_1[5].answer[0],quiz.question_1[5].answer[1]);
			}
			idcount++;
		}
	}
	document.getElementById('container-main').innerHTML += container;
}


var input_len = $('input').length;
function showanswer(){
	for(i=1;i<=input_len;i++){
		$('input#input-id-'+i+':checked').each(function() {
			var a = $('input#input-id-'+i+':checked').attr('id');
			var data_type = $('input#input-id-'+i+':checked').attr('data-type');
			
			if(data_type == answer_array[0] || data_type == answer_array[1]){
				$('#correct_div_'+i+'').css('display','block');
			}else{
				$('#wrong_div_'+i+'').css('display','block');
			}
		});
	}
}

function check(){
	$('#correct_div_'+answer_array[0]+'').css('display','block');
	$('#correct_div_'+answer_array[1]+'').css('display','block');
	$('#wrong_div_1,#wrong_div_3').css('display','block');
}

function reset(){
	for(i=1;i<=input_len;i++){
		$('#correct_div_'+i+'').css('display','none');	
		$('#wrong_div_'+i+'').css('display','none');	
	}
}
