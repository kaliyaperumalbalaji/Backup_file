var quiz = {
	"question1":[
			{"question": "What is the capital of United Kingdom?<lh>30"},
			{"choices": "Manchester"},
			{"choices": "Birmingham"},
			{"choices": "London"},
			{"choices": "Birmingham"},
			{"answer": "3"}
			// {"textarea":"What is your name"}
		],
	"question2":[
			{"question": "What is the capital of United States?<lh>30"},
			{"choices": "California"},
			{"choices": "New York"},
			{"choices": "Miami"},
			{"choices": "Florida"},
			{"answer": "2"}
			// {"img":"images/tick.png"}
			
		],
	"question3":[
			{"question": "What is my Name?<lh>30"},
			{"choices": "Hero"},
			{"choices": "Villain"},
			{"choices": "Comedian"},
			{"choices": "None"},
			{"answer": "3"}
			// {"textarea":""}
		],
	"question4":[
			{"question": "What is my Name?<cl>red"},
			{"choices": "Hero"},
			{"choices": "Villain"},
			{"choices": "Comedian"},
			{"choices": "None"},
			{"answer": "3"}
			// {"textarea":""}
		],
	"question5":[
			{"question": "What is my Name?<lh>100<cl>red"},
			{"choices": "Hero"},
			{"choices": "Villain"},
			{"choices": "Comedian"},
			{"choices": "None"},
			{"answer": "3"}
			// {"textarea":""}
		]
}